'use client';
import AuthGuard from '../../components/AuthGuard';
import Nav from '../../components/Nav';
export default function Customers() {
  return (<AuthGuard><Nav/><main className="max-w-6xl mx-auto p-4"><div className="card"><h2 className="font-bold text-lg">Customers scaffold</h2><p className="text-gray-400">This page is prepared for future expansion.</p></div></main></AuthGuard>);
}
