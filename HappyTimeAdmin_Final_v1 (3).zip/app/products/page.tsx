'use client';
import AuthGuard from '../../components/AuthGuard';
import Nav from '../../components/Nav';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { useForm } from 'react-hook-form';
import { v4 as uuidv4 } from 'uuid';
import { useTranslation } from 'react-i18next';
type Product = { id:string; name:string; price:number; image_url?:string|null };
export default function Products(){
  const [items,setItems] = useState<Product[]>([]);
  const [editing,setEditing] = useState<Product|null>(null);
  const { register, handleSubmit, reset } = useForm<{name:string; price:number; image?:FileList}>();
  const { t } = useTranslation();
  const load = async () => {
    const { data } = await supabase.from('products').select('*').order('created_at',{ascending:false});
    setItems((data as Product[])||[]);
  };
  useEffect(()=>{ load(); },[]);
  const onSubmit = async (vals:any) => {
    let image_url = editing?.image_url ?? null;
    const bucket = process.env.NEXT_PUBLIC_BUCKET || 'product-images';
    if(vals.image && vals.image[0]){
      const file: File = vals.image[0];
      const ext = file.name.split('.').pop();
      const key = `products/${uuidv4()}.${ext}`;
      const { error } = await supabase.storage.from(bucket).upload(key, file, { upsert:false });
      if(error) return alert(error.message);
      const { data: pub } = supabase.storage.from(bucket).getPublicUrl(key);
      image_url = pub.publicUrl;
    }
    if(editing){
      const { error } = await supabase.from('products').update({ name: vals.name, price: vals.price, image_url }).eq('id', editing.id);
      if(error) return alert(error.message);
    } else {
      const { error } = await supabase.from('products').insert({ name: vals.name, price: vals.price, image_url });
      if(error) return alert(error.message);
    }
    setEditing(null); reset(); await load();
  };
  const del = async (p:Product) => {
    if(!confirm('Delete?')) return;
    const { error } = await supabase.from('products').delete().eq('id', p.id);
    if(error) return alert(error.message);
    await load();
  };
  return (
    <AuthGuard>
      <Nav/>
      <main className="max-w-6xl mx-auto p-4">
        <div className="card mb-4">
          <h2 className="font-bold mb-3">{editing ? 'Edit' : t('addProduct')}</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="grid md:grid-cols-4 gap-3">
            <input className="input" placeholder={t('name')!} {...register('name',{required:true})} defaultValue={editing?.name}/>
            <input className="input" placeholder={t('price')!} type="number" step="0.001" {...register('price',{valueAsNumber:true})} defaultValue={editing?.price}/>
            <input className="input file:mr-2 file:px-3 file:py-2 file:border-0 file:rounded-md file:bg-primary file:text-white" type="file" accept="image/*" {...register('image')}/>
            <button className="btn">{t('save')}</button>
          </form>
        </div>
        <div className="grid gap-3 md:grid-cols-3">
          {items.length===0 && <div className="text-gray-400">{t('noData')}</div>}
          {items.map(p => (
            <div key={p.id} className="card">
              {p.image_url && <img src={p.image_url} alt={p.name} className="w-full h-40 object-cover rounded-md mb-3"/>}
              <div className="font-semibold">{p.name}</div>
              <div className="text-sm text-gray-400">{p.price}</div>
              <div className="mt-3 flex gap-2">
                <button className="btn" onClick={()=>setEditing(p)}>{t('edit')}</button>
                <button className="btn" onClick={()=>del(p)}>{t('delete')}</button>
              </div>
            </div>
          ))}
        </div>
      </main>
    </AuthGuard>
  );
}
