'use client';
import AuthGuard from '../../components/AuthGuard';
import Nav from '../../components/Nav';
import { useTranslation } from 'react-i18next';
import { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
export default function Dashboard(){
  const { t } = useTranslation();
  const [stats,setStats] = useState({orders:0, customers:0, sales:0, products:0});
  useEffect(()=>{ (async()=>{
    const { count: pc } = await supabase.from('products').select('*',{ count:'exact', head:true });
    setStats(s=>({ ...s, products: pc ?? 0 }));
  })(); },[]);
  const Card = ({title,value,emoji}:{title:string,value:number|string,emoji:string}) => (
    <div className="card"><div className="text-3xl mb-2">{emoji}</div><div className="text-sm text-gray-300">{title}</div><div className="text-2xl font-bold">{value}</div></div>
  );
  return (
    <AuthGuard>
      <Nav/>
      <main className="max-w-6xl mx-auto p-4 grid gap-4 md:grid-cols-4">
        <Card title={t('stats.orders')} value={0} emoji="🛒"/>
        <Card title={t('stats.customers')} value={0} emoji="👥"/>
        <Card title={t('stats.sales')} value={0} emoji="💰"/>
        <Card title={t('stats.products')} value={stats.products} emoji="📦"/>
      </main>
    </AuthGuard>
  );
}
