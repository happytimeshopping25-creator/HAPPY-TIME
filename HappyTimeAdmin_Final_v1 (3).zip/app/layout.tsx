import './globals.css'
import { ReactNode } from 'react'
import Providers from '../components/Providers'
export const metadata = { title: 'Happy Time Admin', description: 'Admin dashboard' }
export default function RootLayout({ children }:{children:ReactNode}){
  return (<html lang="ar" dir="rtl" suppressHydrationWarning><body><Providers>{children}</Providers></body></html>)
}
