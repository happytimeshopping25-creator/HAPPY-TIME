'use client';
import { useForm } from 'react-hook-form';
import { supabase } from '../lib/supabase';
import { useRouter } from 'next/navigation';
import { useTranslation } from 'react-i18next';
type Form = { email:string; password:string; };
export default function Login(){
  const { register, handleSubmit, formState:{isSubmitting} } = useForm<Form>();
  const router = useRouter();
  const { t, i18n } = useTranslation();
  const onSubmit = async (vals:Form) => {
    const { error } = await supabase.auth.signInWithPassword(vals);
    if(error) alert(error.message); else router.push('/dashboard');
  };
  if(i18n.language!=='ar'){ i18n.changeLanguage('ar'); document.documentElement.dir='rtl'; }
  return (
    <main className="min-h-screen grid place-items-center">
      <div className="card w-full max-w-md">
        <div className="text-center mb-4">
          <img src="/logo.png" alt="logo" className="w-16 h-16 mx-auto mb-2"/>
          <h1 className="text-xl font-bold">{t('login')}</h1>
        </div>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-3">
          <div><label className="label">{t('email')}</label><input type="email" className="input" required {...register('email')}/></div>
          <div><label className="label">{t('password')}</label><input type="password" className="input" required {...register('password')}/></div>
          <button disabled={isSubmitting} className="btn w-full">{t('signIn')}</button>
        </form>
      </div>
    </main>
  );
}
