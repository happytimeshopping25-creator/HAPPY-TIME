'use client';
import { useEffect } from 'react';
export function useTheme(){
  useEffect(()=>{
    const pref = localStorage.getItem('theme') || 'dark';
    if(pref==='dark') document.documentElement.classList.add('dark');
    else document.documentElement.classList.remove('dark');
  },[]);
}
export function toggleTheme(){
  const isDark = document.documentElement.classList.toggle('dark');
  localStorage.setItem('theme', isDark ? 'dark' : 'light');
}
