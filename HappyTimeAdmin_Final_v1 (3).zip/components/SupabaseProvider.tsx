'use client';
import { ReactNode } from 'react';
export function SupabaseProvider({children}:{children:ReactNode}){ return <>{children}</>; }
