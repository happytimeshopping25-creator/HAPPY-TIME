'use client';
import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useRouter } from 'next/navigation';
export default function AuthGuard({children}:{children:React.ReactNode}){
  const [ok,setOk] = useState(false);
  const router = useRouter();
  useEffect(()=>{
    supabase.auth.getSession().then(({data})=>{
      if(!data.session) router.push('/'); else setOk(true);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_e,session)=>{ if(!session) router.push('/'); });
    return ()=>{ sub.subscription.unsubscribe(); };
  },[router]);
  if(!ok) return null;
  return <>{children}</>;
}
