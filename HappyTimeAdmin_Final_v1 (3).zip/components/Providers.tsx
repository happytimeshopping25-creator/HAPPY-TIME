'use client';
import { ReactNode, useEffect } from 'react';
import { I18nextProvider } from 'react-i18next';
import i18n from '../lib/i18n';
import { SupabaseProvider } from './SupabaseProvider';
import { useTheme } from '../lib/theme';
export default function Providers({children}:{children:ReactNode}){
  useTheme();
  useEffect(()=>{ document.documentElement.dir = i18n.dir(i18n.language); },[]);
  return (<I18nextProvider i18n={i18n}><SupabaseProvider>{children}</SupabaseProvider></I18nextProvider>);
}
