'use client';
import Link from 'next/link';
import { useTranslation } from 'react-i18next';
import { toggleTheme } from '../lib/theme';
import { supabase } from '../lib/supabase';
import { useRouter, usePathname } from 'next/navigation';
export default function Nav(){
  const { t, i18n } = useTranslation();
  const router = useRouter();
  const pathname = usePathname();
  const changeLang = () => {
    const next = i18n.language==='ar'?'en':'ar';
    i18n.changeLanguage(next);
    document.documentElement.dir = i18n.dir(next);
  };
  const logout = async () => { await supabase.auth.signOut(); router.push('/'); };
  const link = (href:string, label:string) => (
    <Link href={href} className={`navlink ${pathname===href?'bg-card border border-border':''}`}>{label}</Link>
  );
  return (
    <header className="sticky top-0 z-20 border-b border-border bg-surface/80 backdrop-blur">
      <div className="max-w-6xl mx-auto flex items-center justify-between p-3">
        <div className="flex items-center gap-3">
          <img src="/logo.png" className="w-9 h-9 rounded-lg" alt="logo"/>
          <span className="font-semibold text-lg hidden sm:block">{t('siteName')}</span>
        </div>
        <nav className="flex items-center gap-2 text-sm">
          {link('/dashboard', t('dashboard'))}
          {link('/products', t('products'))}
          {link('/orders', t('orders'))}
          {link('/offers', t('offers'))}
          {link('/customers', t('customers'))}
          {link('/users', t('users'))}
          {link('/settings', t('settings'))}
        </nav>
        <div className="flex items-center gap-2">
          <button onClick={changeLang} className="btn">{i18n.language==='ar'?t('english'):t('arabic')}</button>
          <button onClick={()=>toggleTheme()} className="btn">{t('toggleTheme')}</button>
          <button onClick={logout} className="btn">{t('logout')}</button>
        </div>
      </div>
    </header>
  );
}
