# Happy Time Admin (Next.js 14 + Supabase)
Dark-first, Arabic-first, products CRUD with image upload to Supabase Storage.

## Run
cp .env.local.example .env.local
npm install
npm run dev
